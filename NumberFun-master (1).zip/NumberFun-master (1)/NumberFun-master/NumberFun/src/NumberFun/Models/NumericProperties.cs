﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NumberFun.Models
{
    public class NumericProperties
    {
        public int Number { get; set; }
        public NumericProperties(int num)
        {
            Number = num;
        }


        //I am unsure if this is correct, because I have had extreme trouble getting this project to work.
        public bool isPrime()
        {
            int Count = 0;
            for (int i = 1; i <= Number; i++)
            {
                if (Number % i == 0)
                {
                    Count++;
                }
            }
            if (Count == 2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        private bool isPrime(int num)
        {
            int Count = 0;
            for (int i = 1; i <= num; i++)
            {
                if (num % i == 0)
                {
                    Count++;
                }
            }
            if (Count == 2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool isPerfect()
        {
            int total = 0;
            for (int i = 1; i < Number; i++)
            {
                if (Number % i == 0)
                {
                    total = total + i;
                }
            }
            if (total == Number)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        public bool isSquareful()
        {
            for (int i = 1; i <= Number; i++)
            {
              if (Number % i == 0)
                {
                    if (isPrime(i) == true)
                    {
                        if (Number % (i * i) == 0)
                        {
                            return true;
                        }

                    }
                }
            }
            return false;
        }

        public bool isSquarefull()
        {
            for (int i = 1; i <= Number; i++)
            {
                if (Number % i == 0)
                {
                    if (isPrime(i) == true)
                    {
                        if (Number % (i * i) != 0)
                        {
                            return false;
                        }

                    }
                }
            }
            return true;
        }

        public bool isPalindrome()
        {
            int num = Number;
            int remainder;
            int reverse = 0;
            int temp;

            temp = num;
            while (num > 0)
            {
                remainder = num % 10;
                reverse = reverse * 10 + remainder;
                num /= 10;
            }

            if (temp == reverse)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}